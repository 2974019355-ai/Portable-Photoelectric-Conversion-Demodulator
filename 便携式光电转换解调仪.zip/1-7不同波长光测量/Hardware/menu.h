#ifndef __menu_H
#define __menu_H

void Menu_Peripheral_Init(void);
void Show_UI(void);
void Show_UI1(void);
void Multiple_pages(void);   

#endif
