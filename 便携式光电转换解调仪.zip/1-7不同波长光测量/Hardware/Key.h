#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
uint8_t Key_GetNum(void);
void EXTI9_5_IRQHandler(void);
uint8_t Key_BuleGetNum(void);

#endif
