#ifndef __SERIAL_H
#define __SERIAL_H

#include <stdio.h>

extern char Serial_RxPacket[];
extern uint8_t Serial_RxFlag;

void Serial_DMA_Init(void);
void Serial_SendByte(uint8_t Byte);
void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString(char *String);
void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf(char *format, ...);

void DMA_Init_USART1_TX(void);
void USART1_DMA_Send(uint8_t *data, uint16_t len);
void Send_ADC_WithProtocol(float value);
void Serial_DMA_Printf(const char *format, ...);
void USART1_DMA_Send(uint8_t *data, uint16_t len);

#endif
